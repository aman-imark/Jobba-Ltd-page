<svg style="display:none;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">

    <symbol id="bg-logo" viewBox="0 0 228 228" fill="#000"><path d="M0,0V228l228-77.168V77.87Z" transform="translate(0 0)" /></symbol>

</svg>