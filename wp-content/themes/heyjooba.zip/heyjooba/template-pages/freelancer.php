<?php
/*
Template Name: Freelancer
*/
get_header();
?>
<style>
    body{
        background-color: #1DD3B0;
    }
    .freelancer-pop a {
        display: none;
    }
</style>

<header class="freelancer-header">
    <div class="container">
        <a class="navbar-brand" href="javascrit:void(0)">
            <img src="https://heyjooba.customerdevsites.com/wp-content/themes/heyjooba/images/logo.svg" alt="">
            <svg width="228" height="228">
                <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#bg-logo"></use>
            </svg>
        </a>
    </div>
</header>
<section class="freelancer uSpace">
    <div class="container">
        <div class="common-heading">
            <h2 class="text-dark">How to work freelance</h2>
        </div>
        <div class="free-text">
            <div class="how">
                <h3>How to work freelance</h3>
                <p>Working as a freelancer means deciding on a business structure, and you have two choices:</p>
                <ol>
                    <li>Working as a sole trader - meaning you are your business.</li>
                    <li>registering as a limited company - meaning you are separate from, but fully responsible for your limited company</li>
                </ol>
                <p>We strongly recommend getting advice to see what’s best for you. Try reaching out to any family or friends who are accountants or if you don’t know any, reach out to a local accountant and get some advice. You’ll be able to find a local accountancy firm by clicking this link: <a href="https://www.local-accountants-uk.co.uk/">https://www.local-accountants-uk.co.uk/</a></p>
            </div>
            <div class="how">
                <h3>Freelancing as a sole trader</h3>
                <p>Typically, sole traders have less paperwork and more privacy than limited companies. Saying that, you will still need to complete your tax return each year. That is something you can not avoid. Either get help and make sure you complete it yourself at the end of the financial year or pay an accountant to do it for you. Do NOT brush it under the carpet.</p>
                <p>Find out more about becoming a sole trader here: <a href="https://www.gov.uk/set-up-sole-trader">https://www.gov.uk/set-up-sole-trader</a></p>
            </div>
            <div class="how">
                <h3>Freelancing as a limited company</h3>
                <p>Limited companies are separate legal entities to you, meaning your personal assets won’t be liable if your business goes into debt. However, there’s much more paperwork, rules and regulations involved when setting up (and running) a limited company. You’ll need to complete a company tax return and your own self-assessment annually. These two bits of unavoidable.</p>
                <p>Creating a limited company is really easy. It literally takes 10 minutes and costs only £12. You can learn more here: <a href="https://www.gov.uk/limited-company-formation/register-your-company">https://www.gov.uk/limited-company-formation/register-your-company"</a></p>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>