<svg style="display:none;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">

    <symbol id="bg-logo" viewBox="0 0 228 228" fill="#000"><path d="M0,0V228l228-77.168V77.87Z" transform="translate(0 0)" /></symbol>

</svg>

<!-- jQuery first, then Bootstrap JS. -->
  <script src="<?php echo get_template_directory_uri();?>/dashboard-employer/js/bundle.min.js"></script>
  <script src="<?php echo get_template_directory_uri();?>/dashboard-employer/js/custom.js"></script>

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
       <script src="https://oss.maxcdn.com/html5shiv/latest/html5shiv.min.js"></script>
       <script src="https://oss.maxcdn.com/respond/latest/respond.min.js"></script>
     <![endif]-->
<!-- For Developer use -->
<script src="<?php echo get_template_directory_uri(); ?>/js/developer.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
</body>

</html>