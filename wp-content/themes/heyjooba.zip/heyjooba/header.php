<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>heyjobba</title>
    <meta name="title" content="Heyjobba">
    <meta name="description" content="Heyjobba">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo get_template_directory_uri();?>/favicon.png" sizes="32x32" type="image/x-icon">
    <link rel="stylesheet" href="https://use.typekit.net/swa7sqq.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/main.css">
</head>
        
<body>